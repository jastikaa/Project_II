#include "writepoem.h"
#include "ui_writepoem.h"
#include "db.h"

writepoem::writepoem(QWidget *parent, const QString& userId)
    : QDialog(parent)
    , ui(new Ui::writepoem)
    , currentUserId(userId)
{
    ui->setupUi(this);
    
    // Connect the submit button
    connect(ui->btn_submit, &QPushButton::clicked, this, &writepoem::on_buttonSave_clicked);
}

writepoem::~writepoem()
{
    delete ui;
}

void writepoem::on_buttonSave_clicked()
{
    QString title = ui->lineEdit->text().trimmed();
    QString content = ui->poemarea->toPlainText().trimmed();
    QString category = ui->comboBox->currentText();

    if (title.isEmpty() || content.isEmpty()) {
        QMessageBox::warning(this, "Error", "Please fill in both title and content");
        return;
    }

    QString result = Database::getInstance().addPoem(currentUserId, title, content, category);
    if (!result.isEmpty() && result != "Error") {  // Ensure valid return value
        QMessageBox::information(this, "Success", "Poem saved successfully!");
        accept();
    } else {
        QMessageBox::critical(this, "Error", "Failed to save poem");
    }

}

void writepoem::on_buttonCancel_clicked()
{
    reject();}
