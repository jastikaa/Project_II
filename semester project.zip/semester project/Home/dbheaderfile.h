#ifndef DBHEADERFILE_H
#define DBHEADERFILE_H
#include <QDialog>
#include <QSqlQueryModel>
#include <QDialog>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#endif // DBHEADERFILE_H

#include <QDialog>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
